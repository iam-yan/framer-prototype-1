export const Primitives = {
    color: {
        primary: "#05F",
    },
}
