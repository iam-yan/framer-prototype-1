export const Primitives = {
    color: {
        brand: "#05F",
    },
}
