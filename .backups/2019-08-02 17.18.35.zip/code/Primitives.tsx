export const primitives = {
    color: {
        brand: "#F0E5FF",
        tint: "#F3F3F3",
    },
}
