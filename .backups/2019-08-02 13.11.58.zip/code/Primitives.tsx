export const primitives = {
    color: {
        brand: "#05F",
    },
}
