export const primitives = {
    color: {
        brand: "#05F",
        tint: "#F0E5FF",
    },
}
