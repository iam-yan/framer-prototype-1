export const primitives = {
    color: {
        brand: "#F0E5FF",
        tint: "#F6F6F6",
    },
}
