import { Data, Override } from "framer"

const sa = Data({
    scrollPosition: 0,
    scrollDirection: "down",
    pointOfChange: 0,
})

let posTracker = 0

export function getScrollData(): Override {
    return {
        onScroll(obj) {
            const point = obj.point

            sa.scrollPosition = -point.y

            if (sa.scrollPosition > posTracker) {
                if (sa.scrollDirection != "down") {
                    sa.pointOfChange = sa.scrollPosition
                }
                sa.scrollDirection = "down"
            } else {
                if (sa.scrollDirection != "up") {
                    sa.pointOfChange = sa.scrollPosition
                }
                sa.scrollDirection = "up"
            }

            posTracker = -point.y
        },
    }
}

export const useScrollData: Override = () => {
    return {
        scrollPosition: sa.scrollPosition,
        scrollDirection: sa.scrollDirection,
        pointOfChange: sa.pointOfChange,
    }
}
