import { Data, Override } from "framer";

const data = Data({
  text: "Placeholder Text"
});

// Attach this override to the input
export const getText: Override = () => {
  return {
    value: data.text,
    onValueChange: (value: string) => {
      data.text = value;
    }
  };
};

// Attach this override to the text you want to display
export const useText: Override = () => {
  return {
    text: data.text
  };
};
