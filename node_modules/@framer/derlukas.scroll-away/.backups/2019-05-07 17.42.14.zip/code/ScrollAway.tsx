import * as React from "react"
import { PropertyControls, ControlType, Frame } from "framer"

const noChildrenStyle: React.CSSProperties = {
    height: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    color: "#8855FF",
    background: "rgba(136, 85, 255, 0.1)",
    overflow: "hidden",
    fontSize: 12,
}

interface Props {
    offset: number
    tolerance: number
    alignment: string
    width: number
    height: number
    effect: string
    hideDirection: string
    transitionTime: number
    transitionCurve: string
    customCurve: string
    scrollDirection: string
    scrollPosition: number
    pointOfChange: number
}

interface State {
    visible: boolean
}

let toleranceCounter = 0

export class ScrollAway extends React.Component<Partial<Props>, State> {
    static defaultProps = {
        offset: 50,
        tolerance: 30,
        alignment: "flex-start",
        width: 300,
        height: 80,
        effect: "move",
        hideDirection: "top",
        transitionTime: 500,
        transitionCurve: "linear",
        customCurve: "cubic-bezier(.10, .10, .25, .90)",
        scrollDirection: "down",
        scrollPosition: 0,
        pointOfChange: 0,
    }

    state = {
        visible: true,
    }

    static propertyControls: PropertyControls = {
        offset: { type: ControlType.Number, title: "Offset" },
        tolerance: { type: ControlType.Number, title: "Tolerance" },
        alignment: {
            type: ControlType.SegmentedEnum,
            options: ["flex-start", "center", "flex-end"],
            optionTitles: ["Left", "Center", "Right"],
            defaultValue: "flex-start",
            title: "Alignment",
        },
        effect: {
            type: ControlType.Enum,
            options: ["move", "fade", "fade-move", "zoom"],
            optionTitles: ["Move", "Fade", "Fade Move", "Zoom"],
            title: "Effect",
        },
        hideDirection: {
            type: ControlType.SegmentedEnum,
            options: ["top", "down", "left", "right"],
            optionTitles: ["↑", "↓", "←", "→"],
            defaultValue: "top",
            title: "Direction",
            hidden(props) {
                return props.effect == "fade"
            },
        },
        transitionCurve: {
            type: ControlType.Enum,
            options: [
                "linear",
                "easeIn",
                "easeOut",
                "easeInOut",
                "circIn",
                "circOut",
                "circInOut",
                "backIn",
                "backOut",
                "backInOut",
                "anticipate",
                //"custom",
            ],
            optionTitles: [
                "linear",
                "easeIn",
                "easeOut",
                "easeInOut",
                "circIn",
                "circOut",
                "circInOut",
                "backIn",
                "backOut",
                "backInOut",
                "anticipate",
                //"cubicBezier...",
            ],
            title: "Easing",
        },
        // customCurve: {
        //   type: ControlType.String,
        // title: "Custom",
        // hidden(props) {
        //   return props.transitionCurve != "custom"
        //},
        //},
        transitionTime: {
            type: ControlType.Number,
            min: 0,
            max: 5000,
            unit: "ms",
            step: 50,
            title: "Timing",
        },
    }

    prevDirection = this.props.scrollDirection
    componentWillReceiveProps(props: Props) {
        if (this.props.scrollPosition >= this.props.offset) {
            if (this.props.scrollDirection == "up") {
                toleranceCounter =
                    this.props.pointOfChange + -this.props.scrollPosition

                if (
                    !this.state.visible &&
                    toleranceCounter >= this.props.tolerance
                ) {
                    this.setState({ visible: true })
                }
            } else {
                toleranceCounter =
                    -this.props.pointOfChange + this.props.scrollPosition

                if (
                    this.state.visible &&
                    toleranceCounter >= this.props.tolerance
                ) {
                    this.setState({ visible: false })
                }
            }
        } else {
            this.setState({ visible: true })
        }

        this.prevDirection = this.props.scrollDirection
    }

    render() {
        if (this.props.children.length > 0) {
            let transition
            if (this.props.transitionCurve == "custom") {
                transition = this.props.customCurve
            } else {
                transition = this.props.transitionCurve
            }

            let directionAnimation
            switch (this.props.hideDirection) {
                case "right":
                    directionAnimation = { x: "100%", y: 0 }
                    break
                case "down":
                    directionAnimation = { x: 0, y: "100%" }
                    break
                case "left":
                    directionAnimation = { x: "-100%", y: 0 }
                    break
                default:
                    directionAnimation = { x: 0, y: "-100%" }
            }

            let variants
            if (this.props.effect == "move") {
                // Move
                variants = {
                    show: {
                        x: 0,
                        y: 0,
                    },
                    hide: directionAnimation,
                }
            } else if (this.props.effect == "fade-move") {
                // Fade Move
                variants = {
                    show: {
                        x: 0,
                        y: 0,
                        opacity: 1,
                    },
                    hide: Object.assign(directionAnimation, { opacity: 0 }),
                }
            } else if (this.props.effect == "zoom") {
                // Zoom
                variants = {
                    show: {
                        scale: 1,
                        opacity: 1,
                    },
                    hide: {
                        scale: 0,
                        opacity: 0,
                    },
                }
            } else {
                // Fade
                variants = {
                    show: {
                        opacity: 1,
                    },
                    hide: {
                        opacity: 0,
                    },
                }
            }

            return (
                <Frame
                    background="transparent"
                    width={this.props.width}
                    height={this.props.height}
                    style={{
                        display: "flex",
                        justifyContent: this.props.alignment,
                    }}
                    initial="show"
                    variants={variants}
                    animate={this.state.visible ? "show" : "hide"}
                    transition={{
                        duration: this.props.transitionTime / 1000,
                        ease: transition,
                    }}
                >
                    {this.props.children}
                </Frame>
            )
        } else {
            return (
                <div style={noChildrenStyle}>
                    Connect to the frame you want to hide ⟶
                </div>
            )
        }
    }
}
