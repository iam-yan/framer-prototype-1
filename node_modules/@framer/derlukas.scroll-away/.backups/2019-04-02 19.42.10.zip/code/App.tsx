import { Data, Override } from "framer";

const sa = Data({
  scrollPosition: 0,
  scrollDirection: "down",
  pointOfChange: 0,
  toleranceCounter: 0
});

let posTracker = 0;
let toleranceCounter = 0;

export const getScrollData: Override = props => {
  return {
    onMove: point => {
      sa.scrollPosition = -point.y;

      if (sa.scrollPosition > posTracker) {
        if (sa.scrollDirection != "down") {
          sa.pointOfChange = sa.scrollPosition;
          sa.toleranceCounter = 0;
        }
        sa.scrollDirection = "down";
      } else {
        if (sa.scrollDirection != "up") {
          sa.pointOfChange = sa.scrollPosition;
          sa.toleranceCounter = 0;
        }
        sa.scrollDirection = "up";
      }

      posTracker = -point.y;
    }
  };
};

// Attach this override to the text you want to display
export const useScrollData: Override = () => {
  return {
    style: () => {
      console.log(sa.scrollPosition);
    }
  };
};

// prevDirection = sa.scrollDirection;
// componentWillReceiveProps(props: Props) {
//   if (sa.scrollPosition >= this.props.offset) {
//     if (sa.scrollDirection == "up") {
//       toleranceCounter = sa.pointOfChange + -sa.scrollPosition;

//       if (!this.state.visible && toleranceCounter >= this.props.tolerance) {
//         this.setState({ visible: true });
//       }
//     } else {
//       toleranceCounter = -sa.pointOfChange + sa.scrollPosition;

//       if (this.state.visible && toleranceCounter >= this.props.tolerance) {
//         this.setState({ visible: false });
//       }
//     }
//   } else {
//     this.setState({ visible: true });
//   }

//   this.prevDirection = sa.scrollDirection;
// }
