import { Data, Override } from "framer";

const sa = Data({
  scrollPosition: 0,
  scrollDirection: "down",
  pointOfChange: 0,
  toleranceCounter: 0
});

let posTracker = 0;
let toleranceCounter = 0;

export const getScrollData: Override = props => {
  return {
    onMove: point => {
      sa.scrollPosition = -point.y;

      if (sa.scrollPosition > posTracker) {
        if (sa.scrollDirection != "down") {
          sa.pointOfChange = sa.scrollPosition;
          sa.toleranceCounter = 0;
        }
        sa.scrollDirection = "down";
      } else {
        if (sa.scrollDirection != "up") {
          sa.pointOfChange = sa.scrollPosition;
          sa.toleranceCounter = 0;
        }
        sa.scrollDirection = "up";
      }

      posTracker = -point.y;
    }
  };
};

// Attach this override to the text you want to display
export const useScrollData: Override = () => {
  return {
    scrollPosition: sa.scrollPosition,
    scrollDirection: sa.scrollDirection,
    toleranceCounter: sa.toleranceCounter,
    pointOfChange: sa.pointOfChange
  };
};
